import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import EmployeeAttendanceDetail from './viewProfile/EmployeeAttendanceDetail.jsx'
import EmployeeAbout from './viewProfile/EmployeeAbout.jsx';
import EmployeeLive from './viewProfile/EmployeeLive.jsx';
import Card from './viewProfile/card.jsx';
const EmployeeDetail = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('about');

  const employee = {
    id: 'DNA0025',
    name: 'Jitendra Singh Chuhan',
    initials: 'AM',
    workEmail: 'usjitendra@codecrafter.com',
    email: 'usjitendra055@gmail.com',
    workPhone: 'None',
    phone: '9876540002',
    personal: {
      dob: 'None',
      gender: 'male',
      address: 'None',
      country: 'None',
      state: 'None',
      city: 'None',
      qualification: 'None',
      experience: 'None',
      maritalStatus: 'Single',
      children: 'None',
      emergencyContact: 'None',
      emergencyContactName: 'None',
      emergencyContactRelation: 'None'
    },
    work: {
      department: 'S/W Dept',
      position: 'Odoo Dev - (S/W Dept)',
      shiftInfo: 'Regular Shift',
      workType: 'None',
      employeeType: 'Temporary',
      manager: 'MANIKANDAN KARICHERI NARAYANAN AVVADUKAM (DNA0007)',
      company: 'Horilla',
      location: 'India',
      endDate: 'None',
      joiningDate: 'Jan. 1, 2024',
      tags: 'None',
      salary: '15000'
    },
    bank: {
      name: 'None',
      accountNumber: 'None',
      branch: 'None',
      code1: 'None',
      address: 'None',
      country: 'None',
      code2: 'None'
    }
  };

  const tabs1 = [
    { id: 'about', label: 'About' },
    // { id: 'workType', label: 'Work Type & Shift' },
    { id: 'attendance', label: 'Attendance' },
    { id: 'leave', label: 'Leave' },
    // { id: 'payroll', label: 'Payroll' },
    // { id: 'allowance', label: 'Allowance & Deduction' },
    // { id: 'penalty', label: 'Penalty Account' },
    // { id: 'history', label: 'History' },
    // { id: 'assets', label: 'Assets' }
  ];
  const tabs2 = [
  //   { id: 'performance', label: 'Performance' },
  //   { id: 'groups', label: 'Groups & Permissions' },
  //   { id: 'note', label: 'Note' },
  //   { id: 'documents', label: 'Documents' },
  //   { id: 'mailLog', label: 'Mail Log' },
  //   { id: 'bonusPoints', label: 'Bonus Points' }
  ];


  const handleTableClick = (tableId) => {
      setActiveTab(tableId);
  };

  return (
    <div className="flex-col md:flex-row  max-w-10xl mx-auto bg-gray-50">
      {/* Header */}
      <div className="bg-white p-4 flex flex-col md:flex-row items-start md:items-center justify-between border-b">
        <div className="flex items-center mb-4 md:mb-0">
          <div className="relative">
            <div className="h-16 w-16 bg-blue-300 rounded-md flex items-center justify-center text-white text-2xl font-bold">
              {employee.initials}
            </div>
            <div className="absolute bottom-0 right-0 h-4 w-4 bg-green-500 rounded-full border-2 border-white"></div>
          </div>
          <div className="ml-4">
            <h1 className="text-xl font-bold">
              {employee.name} ({employee.id})
            </h1>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-1 mt-2">
              <div className="flex items-center text-gray-600 text-sm">
                <span className="mr-2">📧 Work Email:</span>
                <span>{employee.workEmail}</span>
              </div>
              <div className="flex items-center text-gray-600 text-sm">
                <span className="mr-2">📧 Email:</span>
                <span>{employee.email}</span>
              </div>
              <div className="flex items-center text-gray-600 text-sm">
                <span className="mr-2">📞 Work Phone:</span>
                <span>{employee.workPhone}</span>
              </div>
              <div className="flex items-center text-gray-600 text-sm">
                <span className="mr-2">📞 Phone:</span>
                <span>{employee.phone}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="px-4 overflow-x-auto ">
        <div className="flex space-x-4 ">
          {tabs1.map((tab) => (
            <button
              key={tab.id}
              className={`py-2 px-1 text-sm whitespace-nowrap ${activeTab === tab.id ? 'text-blue-600 border-b-2 border-blue-600 font-medium' : 'text-gray-500'}`}
              onClick={() => handleTableClick(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>
      <div className="px-4 overflow-x-auto ">
        <div className="flex space-x-4 ">
          {tabs2.map((tab) => (
            <button
              key={tab.id}
              className={`py-2 px-1 text-sm whitespace-nowrap ${activeTab === tab.id ? 'text-blue-600 border-b-2 border-blue-600 font-medium' : 'text-gray-500'}`}
              onClick={() => setActiveTab(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

       <div className='mp-4'>
           {activeTab==="attendance" && <EmployeeAttendanceDetail/>}
           {activeTab==="about" && <EmployeeAbout/>}
           {activeTab==="leave" && <EmployeeLive/>} 
       </div>

      {/* Content */}
     
    </div>
  );
};

export default EmployeeDetail;
