
import React from 'react'

export default function EmployeeAbout() {
  
    const employee = {
        id: 'DNA0025',
        name: 'jitendra singh Chauhan',
        initials: 'AM',
        workEmail: 'usjitendra055@codecrafter.com',
        email: 'usjitendra055@gmail.com',
        workPhone: 'None',
        phone: '9876540002',
        personal: {
          dob: '15/06/2002',
          gender: 'Male',
          address: 'jaunpur saray kali das mariahu jaunpur 222161',
          country: 'None',
          state: 'None',
          city: 'None',
          qualification: 'None',
          experience: 'None',
          maritalStatus: 'Single',
          children: 'None',
          emergencyContact: 'None',
          emergencyContactName: 'None',
          emergencyContactRelation: 'None'
        },
        work: {
          department: 'Software Engineer',
          position: 'MERN',
          shiftInfo: 'Regular Shift',
          workType: 'None',
          employeeType: 'Temporary',
          manager: 'codecrafter(DNA0007)',
          company: 'codecrafter.co.in',
          location: 'India',
          endDate: 'None',
          joiningDate: 'Jan. 1, 2024',
          tags: 'None',
          salary: '15000'
        },
        bank: {
          name: 'None',
          accountNumber: 'None',
          branch: 'None',
          code1: 'None',
          address: 'None',
          country: 'None',
          code2: 'None'
        }
      };


        const InfoItem = ({ label, value }) => (
    <div className="mb-4">
      <div className="text-gray-500 text-sm flex items-center">
        <span className="mr-1">
          {label === 'Date of Birth' && (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
              />
            </svg>
          )}
          {label === 'Gender' && (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
              />
            </svg>
          )}
        </span>
        {label}
      </div>
      <div className="text-gray-900">{value}</div>
    </div>
  );

  const infoSection = (title, items) => (
    <div className="p-4 bg-white rounded-md shadow-sm mb-4">
      <h3 className="text-lg font-medium mb-4">{title}</h3>
      <div>
        {items.map((item, index) => (
          <InfoItem key={index} label={item.label} value={item.value} />
        ))}
      </div>
    </div>
  );
      
  return (
    <div>
       <div className="p-4 py-5">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Personal Information */}
          <div className="bg-white rounded-md shadow-sm p-4">
            <h3 className="text-lg font-medium mb-4">Personal Information</h3>
            <InfoItem label="Date of Birth" value={employee.personal.dob} />
            <InfoItem label="Gender" value={employee.personal.gender} />
            <InfoItem label="Address" value={employee.personal.address} />
            <InfoItem label="Country" value={employee.personal.country} />
            <InfoItem label="State" value={employee.personal.state} />
            <InfoItem label="City" value={employee.personal.city} />
            <InfoItem label="Qualification" value={employee.personal.qualification} />
            <InfoItem label="Experience" value={employee.personal.experience} />
            <InfoItem label="Marital Status" value={employee.personal.maritalStatus} />
            <InfoItem label="Children" value={employee.personal.children} />
            <InfoItem label="Emergency Contact" value={employee.personal.emergencyContact} />
            <InfoItem label="Emergency Contact Name" value={employee.personal.emergencyContactName} />
            <InfoItem label="Emergency Contact Relation" value={employee.personal.emergencyContactRelation} />
          </div>

          {/* Work Information */}
          <div className="md:col-span-2">
            <div className="bg-white rounded-md shadow-sm p-4 mb-4">
              <div className="flex items-center mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 text-gray-500 mr-2"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                  />
                </svg>
                <h3 className="text-lg font-medium">Work Information</h3>
                <div className="ml-auto h-2 w-2 bg-red-500 rounded-full"></div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <div className="text-gray-500 text-sm flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
                      />
                    </svg>
                    Department
                  </div>
                  <div className="text-gray-900">{employee.work.department}</div>
                </div>
                <div>
                  <div className="text-gray-500 text-sm flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                      />
                    </svg>
                    Job Position
                  </div>
                  <div className="text-gray-900">{employee.work.position}</div>
                </div>
                <div>
                  <div className="text-gray-500 text-sm flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Shift Information
                  </div>
                  <div className="text-gray-900">{employee.work.shiftInfo}</div>
                </div>
                <div>
                  <div className="text-gray-500 text-sm flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                      />
                    </svg>
                    Work Type
                  </div>
                  <div className="text-gray-900">{employee.work.workType}</div>
                </div>
                <div>
                  <div className="text-gray-500 text-sm flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                      />
                    </svg>
                    Employee Type
                  </div>
                  <div className="text-gray-900">{employee.work.employeeType}</div>
                </div>
                <div>
                  <div className="text-gray-500 text-sm flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                      />
                    </svg>
                    Reporting Manager
                  </div>
                  <div className="text-gray-900">{employee.work.manager}</div>
                </div>
                <div>
                  <div className="text-gray-500 text-sm flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
                      />
                    </svg>
                    Company
                  </div>
                  <div className="text-gray-900">{employee.work.company}</div>
                </div>
                <div>
                  <div className="text-gray-500 text-sm flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"
                      />
                    </svg>
                    Work Location
                  </div>
                  <div className="text-gray-900">{employee.work.location}</div>
                </div>
                <div>
                  <div className="text-gray-500 text-sm flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                      />
                    </svg>
                    End Date
                  </div>
                  <div className="text-gray-900">{employee.work.endDate}</div>
                </div>
                <div>
                  <div className="text-gray-500 text-sm flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                      />
                    </svg>
                    Joining Date
                  </div>
                  <div className="text-gray-900">{employee.work.joiningDate}</div>
                </div>
                <div>
                  <div className="text-gray-500 text-sm flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"
                      />
                    </svg>
                    Tags
                  </div>
                  <div className="text-gray-900">{employee.work.tags}</div>
                </div>
                <div>
                  <div className="text-gray-500 text-sm flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                    Salary
                  </div>
                  <div className="text-gray-900">{employee.work.salary}</div>
                </div>
              </div>
            </div>

            {/* Bank Information */}
            <div className="bg-white rounded-md shadow-sm p-4 py-10">
              <h3 className="text-lg font-medium mb-4">Bank Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <InfoItem label="Bank Name" value={employee.bank.name} />
                <InfoItem label="Account Number" value={employee.bank.accountNumber} />
                <InfoItem label="Branch" value={employee.bank.branch} />
                <InfoItem label="Bank Code #1" value={employee.bank.code1} />
                <InfoItem label="Bank Address" value={employee.bank.address} />
                <InfoItem label="Country" value={employee.bank.country} />
                <InfoItem label="Bank Code #2" value={employee.bank.code2} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}



